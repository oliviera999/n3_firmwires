// Minimal utilities for dropdown/nav and UI helpers
(function(){
  function toggleDropdown(btnId, menuId){
    const btn = document.getElementById(btnId);
    const menu = document.getElementById(menuId);
    if(!btn||!menu) return;
    btn.addEventListener('click', (e)=>{
      e.stopPropagation();
      const opened = menu.classList.contains('show');
      document.querySelectorAll('.dropdown-menu.show').forEach(m=>m.classList.remove('show'));
      if(!opened) menu.classList.add('show');
    });
    document.addEventListener('click', ()=> menu.classList.remove('show'));
  }
  window.UIUtils = { toggleDropdown };
})();
